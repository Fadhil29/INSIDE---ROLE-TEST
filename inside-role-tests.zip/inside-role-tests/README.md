# INSIDE - Role Tests

Test Playwright per role untuk aplikasi INSIDE. Semua role dipakai dari satu akun Super Admin lewat dropdown role.

## Setup
```
npm install
npx playwright install chromium
```
Buat file `.env`:
```
FAMILIA_USERNAME_SUPERADMIN=
FAMILIA_PASSWORD_SUPERADMIN=
```

## Pakai
```
npm run auth                          # login + simpan session semua role
npm run auth -- auditor               # ulang satu role (kalau session expired)
npm run codegen -- auditor safety-report   # record flow -> tests/auditor/safety-report.spec.ts
npm run test:auditor                  # jalankan test satu role
npm test                              # semua role
```
Role: general, admin-safety-kc, admin-safety-region, admin-safety-head-office, auditor, super-admin.
Spec role X ditaruh di `tests/<slug>/`.

Kalau test jalan paralel dan role saling tertukar, set `workers: 1` di `playwright.config.ts`.
